"""Research and knowledge package."""
